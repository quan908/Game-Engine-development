
#pragma once
#include "json.hpp"
#include <fstream>
#include <string>
using json = nlohmann::json;

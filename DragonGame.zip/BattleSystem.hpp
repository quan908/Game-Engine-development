#pragma once
#include "Dragon.hpp"
#include "Player.hpp"

namespace CW {
    float GetTypeMultiplier(DragonType atk, DragonType def);
    bool Battle(Dragon& playerDragon, Dragon& enemyDragon);
    bool BossBattle(Player& player);
}

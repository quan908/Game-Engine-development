#include "Game.hpp"

int main() {
    CW::Player p;
    p.LoadFromJSON("Player.json");
    CW::Game game;
    game.run();
    return 0;
}

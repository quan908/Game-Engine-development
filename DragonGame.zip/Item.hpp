
#pragma once
#include <string>

namespace CW {
    enum ItemType { HealPotion, PowerUp };

    struct Item {
        ItemType type;
        std::string name;
        int value;
        int x, y;
    };
}

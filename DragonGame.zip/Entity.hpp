#pragma once

namespace CW {
    class Entity {
    protected:
        int posX, posY;
        char symbol;
    public:
        Entity(int x = 0, int y = 0, char s = '?');
        void setPosition(int x, int y);
        int getX() const;
        int getY() const;
        char getSymbol() const;
    };
}

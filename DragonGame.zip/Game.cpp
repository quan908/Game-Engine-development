#include "Item.hpp"

#include "Game.hpp"
#include "BattleSystem.hpp"
#include <iostream>
#include <conio.h>
#include <cstdlib>
#include <ctime>

namespace CW {

    Game::Game() : boss("BossHydra", 60, 12, 'B', DragonType::Fire), player(1, 6), isRunning(true) {
        srand(static_cast<unsigned>(time(0)));
        loadMap();
        loadDragons();

        items.push_back({ HealPotion, "Potion", 30, 5, 2 });
        items.push_back({ PowerUp, "PowerUp", 5, 10, 5 });
    }

    void Game::loadMap() {
        mapData = {
            "####################",
            "#..................#",
            "#..............#####",
            "#..............#   #",
            "#..............#   #",
            "#..............#####",
            "#..................#",
            "####################"
        };
    }

    void Game::loadDragons() {
        dragons.push_back(Dragon("FireDrake", 30, 8, 'F', DragonType::Fire));
        dragons.back().setPosition(6, 1);

        dragons.push_back(Dragon("WaterSerpent", 30, 8, 'W', DragonType::Water));
        dragons.back().setPosition(10, 4);

        dragons.push_back(Dragon("EarthGolem", 30, 8, 'E', DragonType::Earth));
        dragons.back().setPosition(6, 4);

        boss.setPosition(17, 6);
    }

    void Game::draw() {
        system("cls");
        for (int y = 0; y < mapData.size(); ++y) {
            for (int x = 0; x < mapData[y].size(); ++x) {
                if (player.getX() == x && player.getY() == y)
                    std::cout << '@';
                else {
                    bool printed = false;

                    for (const auto& item : items) {
                        if (item.x == x && item.y == y) {
                            std::cout << (item.type == HealPotion ? 'P' : 'U');
                            printed = true;
                            break;
                        }
                    }

                    if (!printed) {
                        for (int i = 0; i < dragons.size(); ++i) {
                            if (dragons[i].getX() == x && dragons[i].getY() == y) {
                                std::cout << dragons[i].getSymbol();
                                printed = true;
                                break;
                            }
                        }
                    }

                    if (!printed && boss.getX() == x && boss.getY() == y) {
                        std::cout << boss.getSymbol();
                        printed = true;
                    }

                    if (!printed)
                        std::cout << mapData[y][x];
                }
            }
            std::cout << std::endl;
        }
    }

    void Game::handleInput() {
        if (_kbhit()) {
            char key = _getch();
            int x = player.getX(), y = player.getY();
            if (key == 'w') y--;
            if (key == 's') y++;
            if (key == 'a') x--;
            if (key == 'd') x++;
            if (key == 'x') isRunning = false;

            if (mapData[y][x] != '#') {
                for (int i = 0; i < items.size(); ++i) {
                    if (items[i].x == x && items[i].y == y) {
                        std::cout << "Picked up " << items[i].name << "!" << std::endl;
                        player.addItem(items[i]);
                        items.erase(items.begin() + i);
                        _getch();
                        break;
                    }
                }

                for (int i = 0; i < dragons.size(); ++i) {
                    if (dragons[i].getX() == x && dragons[i].getY() == y) {
                        handleCombat(x, y);
                        return;
                    }
                }
                if (boss.getX() == x && boss.getY() == y) {
                    handleCombat(x, y);
                    return;
                }
                player.setPosition(x, y);
            }
        }
    }

    void Game::handleCombat(int x, int y) {
        for (int i = 0; i < dragons.size(); ) {
            if (dragons[i].getX() == x && dragons[i].getY() == y) {
                Dragon& target = dragons[i];
                if (Battle(player.getActiveDragon(), target)) {
                    std::cout << "You captured " << target.GetName() << "!" << std::endl;
                    player.addDragon(target);
                    dragons.erase(dragons.begin() + i);
                    _getch();
                    continue;
                } else {
                    std::cout << "You lost the battle!" << std::endl;
                    isRunning = false;
                    _getch();
                    return;
                }
            }
            ++i;
        }
        if (boss.getX() == x && boss.getY() == y) {
            if (BossBattle(player)) {
                std::cout << "You defeated the Boss! Game Clear!" << std::endl;
            } else {
                std::cout << "You were defeated by the Boss!" << std::endl;
            }
            isRunning = false;
            _getch();
        }
    }

    void Game::update() {
        draw();
        handleInput();
    }

    void Game::run() {
        while (isRunning) {
            update();
        }
    }
}

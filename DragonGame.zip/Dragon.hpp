#pragma once
#include "Entity.hpp"
#include <string>

namespace CW {
    enum DragonType { Fire, Water, Earth };

    class Dragon : public Entity {
    public:
        Dragon(std::string name, int hp, int atk, char sym, DragonType type);
        std::string GetName() const;
        int GetHP() const;
        int GetATK() const;
        DragonType GetType() const;
        void TakeDamage(int dmg);
    private:
        std::string name;
        int hp, atk;
        DragonType type;
    };
}

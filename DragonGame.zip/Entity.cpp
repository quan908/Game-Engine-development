#include "Entity.hpp"

namespace CW {
    Entity::Entity(int x, int y, char s) : posX(x), posY(y), symbol(s) {}
    void Entity::setPosition(int x, int y) { posX = x; posY = y; }
    int Entity::getX() const { return posX; }
    int Entity::getY() const { return posY; }
    char Entity::getSymbol() const { return symbol; }
}

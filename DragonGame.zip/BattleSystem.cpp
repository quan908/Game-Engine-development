
#include "Item.hpp"
#include "BattleSystem.hpp"
#include <iostream>
#include <cstdlib>
#include <ctime>

namespace CW {

    float GetTypeMultiplier(DragonType atk, DragonType def) {
        if (atk == Fire && def == Earth) return 2.0f;
        if (atk == Water && def == Fire) return 2.0f;
        if (atk == Earth && def == Water) return 2.0f;
        return 1.0f;
    }

    bool Battle(Dragon& playerDragon, Dragon& enemyDragon) {
        while (playerDragon.GetHP() > 0 && enemyDragon.GetHP() > 0) {
            std::cout << "=============================" << std::endl;
            std::cout << "Choose Action: 1 = Attack, 2 = Do Nothing" << std::endl;
            char choice;
            std::cin >> choice;
            if (choice == '1') {
                int dmg = static_cast<int>(playerDragon.GetATK() * GetTypeMultiplier(playerDragon.GetType(), enemyDragon.GetType()));
                enemyDragon.TakeDamage(dmg);
                std::cout << "You hit for " << dmg << "!" << std::endl;
            }
            if (enemyDragon.GetHP() > 0) {
                playerDragon.TakeDamage(enemyDragon.GetATK());
                std::cout << "Enemy hit you!" << std::endl;
            }
        }
        return playerDragon.GetHP() > 0;
    }

    bool BossBattle(Player& player) {
        srand((unsigned)time(0));
        int bossHP = 80;
        int bossATK = 15;

        while (bossHP > 0) {
            std::cout << "=============================" << std::endl;
            std::cout << "Boss Turn!" << std::endl;

            DragonType bossAtk = static_cast<DragonType>(rand() % 3);
            std::string atkName = bossAtk == Fire ? "FIRE" : bossAtk == Water ? "WATER" : "EARTH";
            std::cout << "Boss is using attack type: " << atkName << std::endl;

            std::cout << "Choose action: 1 = Attack | 2 = Use Item" << std::endl;
            char action;
            std::cin >> action;

            if (action == '2') {
                const auto& items = player.getInventory();
                if (items.empty()) {
                    std::cout << "You have no items!" << std::endl;
                } else {
                    std::cout << "Available items:" << std::endl;
                    for (size_t i = 0; i < items.size(); ++i) {
                        std::cout << i << ": " << items[i].name << " (+" << items[i].value 
                                  << (items[i].type == HealPotion ? " HP" : " ATK") << ")" << std::endl;
                    }

                    int itemChoice = 0;
                    std::cin >> itemChoice;
                    const auto& dragons = player.getAllDragons();
                    std::cout << "Choose dragon to use item on:" << std::endl;
                    for (size_t i = 0; i < dragons.size(); ++i) {
                        std::cout << i << ": " << dragons[i].GetName() << " (HP: " 
                                  << dragons[i].GetHP() << ", ATK: " << dragons[i].GetATK() << ")" << std::endl;
                    }

                    int dragonChoice = 0;
                    std::cin >> dragonChoice;
                    if (dragonChoice >= 0 && dragonChoice < dragons.size()) {
                        Dragon& target = const_cast<Dragon&>(dragons[dragonChoice]);
                        player.useItem(itemChoice, target);
                    }
                }
                continue;
            }

            const auto& dragons = player.getAllDragons();
            std::cout << "Choose your dragon to attack with:" << std::endl;
            for (size_t i = 0; i < dragons.size(); ++i) {
                std::string typeStr = dragons[i].GetType() == Fire ? "FIRE" :
                                      dragons[i].GetType() == Water ? "WATER" : "EARTH";
                std::cout << i << ": " << dragons[i].GetName() << " (Type: " << typeStr
                          << ", HP: " << dragons[i].GetHP() << ", ATK: " << dragons[i].GetATK() << ")" << std::endl;
            }

            int choice = 0;
            std::cin >> choice;
            if (choice < 0 || choice >= static_cast<int>(dragons.size())) {
                std::cout << "Invalid choice. Skipping turn!" << std::endl;
                continue;
            }

            Dragon selected = dragons[choice];

            float multiplier = GetTypeMultiplier(selected.GetType(), bossAtk);
            if (multiplier > 1.0f) {
                int dmg = static_cast<int>(selected.GetATK() * multiplier);
                bossHP -= dmg;
                std::cout << "Effective attack! You dealt " << dmg << " damage!" << std::endl;
            } else {
                std::cout << "Your dragon was weak to the boss's element and took " << bossATK << " damage!" << std::endl;
            }
        }

        std::cout << "Boss defeated!" << std::endl;
        return true;
    }
}

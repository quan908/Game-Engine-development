#include "json.hpp"
#include "Item.hpp"
#include <iostream>

#include "Player.hpp"

namespace CW {

Player::Player() : x(0), y(0), hp(0), maxHp(0) {}

    Player::Player(int x, int y) : x(x), y(y) {
        dragons.push_back(Dragon("Starter", 100, 7, '*', Water));
    }

    void Player::setPosition(int px, int py) { x = px; y = py; }
    int Player::getX() const { return x; }
    int Player::getY() const { return y; }

    void Player::addDragon(const Dragon& d) {
        dragons.push_back(d);
    }

    Dragon& Player::getActiveDragon() {
        return dragons[0];
    }

    const std::vector<Dragon>& Player::getAllDragons() const {
        return dragons;
    }

    void Player::addItem(const Item& item) {
        inventory.push_back(item);
    }

    void Player::useItem(int index, Dragon& target) {
        if (index < 0 || index >= inventory.size()) return;

        Item item = inventory[index];
        if (item.type == HealPotion) {
            std::cout << "Used " << item.name << "! Restored " << item.value << " HP!" << std::endl;
            target.TakeDamage(-item.value);
        } else if (item.type == PowerUp) {
            std::cout << "Used " << item.name << "! Boosted ATK by " << item.value << "!" << std::endl;
            target = Dragon(target.GetName(), target.GetHP(), target.GetATK() + item.value, '*', target.GetType());
        }

        inventory.erase(inventory.begin() + index);
    }

    const std::vector<Item>& Player::getInventory() const {
        return inventory;
    }
}


#include "JSONLoader.hpp"

void CW::Player::LoadFromJSON(const std::string& filename) {
    std::ifstream file(filename);
    json j;
    file >> j;
    name = j["name"];
    hp = j["hp"];
    maxHp = j["max_hp"];
    inventoryStr = j["inventory"].get<std::vector<std::string>>();
}

#pragma once
#include "Player.hpp"
#include "Dragon.hpp"
#include <vector>
#include <string>
#include "Item.hpp"

namespace CW {

    class Game {
    public:
        Game();
        void run();
        void update();
        void draw();
        void handleInput();
        void handleCombat(int x, int y);
    private:
        void loadMap();
        void loadDragons();
        std::vector<std::string> mapData;
        std::vector<Dragon> dragons;
        std::vector<Item> items;
        Dragon boss;
        Player player;
        bool isRunning;
    };
}
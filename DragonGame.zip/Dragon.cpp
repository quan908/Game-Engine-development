#include "Dragon.hpp"

namespace CW {
    Dragon::Dragon(std::string name, int hp, int atk, char sym, DragonType type)
        : Entity(0, 0, sym), name(name), hp(hp), atk(atk), type(type) {}

    std::string Dragon::GetName() const { return name; }
    int Dragon::GetHP() const { return hp; }
    int Dragon::GetATK() const { return atk; }
    DragonType Dragon::GetType() const { return type; }
    void Dragon::TakeDamage(int dmg) { hp -= dmg; }
}

#pragma once
#include "Dragon.hpp"
#include <vector>
#include <string>
#include "Item.hpp"

namespace CW {

    class Player {
    public:
        Player();
        void LoadFromJSON(const std::string& filename);
        void SetName(const std::string& n) { name = n; }
        void SetHP(int h) { hp = h; }
        void SetInventory(const std::vector<std::string>& inv) { inventoryStr = inv; }

    private:
        std::string name;
        int hp;
        int maxHp;
        std::vector<std::string> inventoryStr;
    public:
        Player(int x, int y);
        void setPosition(int x, int y);
        int getX() const;
        int getY() const;
        void addDragon(const Dragon& d);
        Dragon& getActiveDragon();
        const std::vector<Dragon>& getAllDragons() const;
        void addItem(const Item& item);
        void useItem(int index, Dragon& target);
        const std::vector<Item>& getInventory() const;
    private:
        int x, y;
        std::vector<Dragon> dragons;
        std::vector<Item> inventory;
    };
}